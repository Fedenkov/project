﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Fedenkov
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            int Standart = 319000;
            int Konfort = 500000;
            int Premium = 800000;
            if (radioButton1.Checked)
            {
                textBox1.Text = Convert.ToString(Standart);
                pictureBox1.Image = Image.FromFile(@"C:\img\8_d_850.jpg");
            }
            if (radioButton2.Checked)
            {
                textBox1.Text = Convert.ToString(Konfort);
                pictureBox1.Image = Image.FromFile(@"C:\img\skoda_rapid_930759.jpg");
            }
            if (radioButton3.Checked)
            {
                textBox1.Text = Convert.ToString(Premium);
                pictureBox1.Image = Image.FromFile(@"C:\img\mercedes-amg-gt-73-four-door-spy-photos.jpg");
            }

        }
    }
}
