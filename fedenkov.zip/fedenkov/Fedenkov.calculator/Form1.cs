﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Fedenkov.calculator
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            double v = double.Parse(textBox2.Text);
            double r = double.Parse(textBox1.Text);
            double i = v / ((r / 100) * (r / 100));
            label5.Text = i.ToString("##.##");
            trackBar1.Value = Convert.ToInt32(i);

            if (i < 18.5)
            {
                pictureBox7.Image = Image.FromFile(@"C:\Users\student\Pictures\bmi-underweight-icon.png");
            }
            if (i > 25)
            {
                pictureBox7.Image = Image.FromFile(@"C:\Users\student\Pictures\bmi-overweight-icon.png");
            }
            if (i >= 18.5)
            {
                pictureBox7.Image = Image.FromFile(@"C:\Users\student\Pictures\bmi-healthy-icon.png");
            }
            if (i > 45)
            {
                pictureBox7.Image = Image.FromFile(@"C:\Users\student\Pictures\bmi-obese-icon.png");
            }

        }

        private void pictureBox7_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
            textBox2.Clear();
        }
    }
}
