﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace fedenkov25
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            double sum;
            double discount;
            double total;
          

            sum = 309000;
            discount = 0;

            if (checkBox4.Checked)
            {
                sum += 200000;
                pictureBox4.Image = Image.FromFile(@"C:\img\7.jpg");

            }

            if (checkBox1.Checked)
            {
                sum += 10000;
                pictureBox1.Image = Image.FromFile(@"C:\img\1.jpg");
                
            }

            if (checkBox2.Checked)
            {
                sum += 7600;
                
                pictureBox2.Image = Image.FromFile(@"C:\img\5jpg.jpg");
               
            }

            if (checkBox3.Checked)
            {
                sum += 8900;
                
                pictureBox3.Image = Image.FromFile(@"C:\img\9.jpg");
            }
            total = sum;
            string st;
            st = "Цена в выбранной комплектации:" + sum.ToString("C");
            label1.Text = st;
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {

        }
    }
}
